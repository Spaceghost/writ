/home/jadams/.local/share/writ-toolchains/bend-2.0.39/bend/bin/bend Tests.bend -o /home/jadams/tmp/writ-posix-frame-verification/full.c 
