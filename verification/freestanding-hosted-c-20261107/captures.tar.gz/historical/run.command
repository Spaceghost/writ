/home/jadams/tmp/writ-freestanding-hosted-20261107/historical/Tests +RTS --threads 1 --gpu off
