#!/usr/bin/env bash
set -u
ulimit -c 0
export TMPDIR=/home/jadams/tmp/writ-codex-20261107
export BEND_NO_TELEMETRY=1
unset BENDRTS
out=/home/jadams/tmp/writ-posix-frame-verification
bend=/home/jadams/.local/share/writ-toolchains/bend-2.0.39/bend/bin/bend
preflight() {
 local stage=$1 available
 available=$(awk '/^MemAvailable:/ {print $2}' /proc/meminfo)
 { printf 'UTC '; date -u +%FT%TZ; printf 'MemAvailable %s KiB; minimum 41943040 KiB\n' "$available"; } > "$out/$stage-memavailable.txt"
 if [ -z "$available" ] || [ "$available" -lt 41943040 ]; then printf '%s preflight refused\n' "$stage" > "$out/native-resource-stop.txt"; return 1; fi
}
step() {
 local name=$1 vm=$2; shift 2
 preflight "$name" || return 42
 printf '%q ' "$@" > "$out/$name.command"; printf '\n' >> "$out/$name.command"
 date -u +%FT%TZ > "$out/$name.start"
 (ulimit -v "$vm"; ulimit -t 600; ulimit -f 262144; timeout 600 "$@") > "$out/$name.stdout" 2> "$out/$name.stderr"
 local result=$?
 date -u +%FT%TZ > "$out/$name.end"
 printf '%s\n' "$result" > "$out/$name.exit"
 printf '%s exit=%s\n' "$name" "$result" >> "$out/native-progress.txt"
 return "$result"
}
{
 printf 'Compiler '; clang --version | head -1
 printf 'Compiler executable '; sha256sum "$(readlink -f "$(command -v clang)")"
 printf 'Linker '; ld --version | head -1
 printf 'C emission/build: nice 15, 600s wall/CPU, 16 GiB virtual memory, 262144 file blocks, no core\n'
 printf 'Run: nice 15, 600s wall/CPU, 20 GiB virtual memory, 262144 file blocks, no core\n'
} > "$out/native-environment.txt"
step native-c-emit 16777216 "$bend" Tests.bend -o "$out/full.c" || exit 1
sha256sum "$out/full.c" > "$out/full-c-before.sha256"
step native-build 16777216 clang -std=c11 -O0 -static "$out/full.c" -o "$out/full-native" -lpthread -lm
build=$?
sha256sum -c "$out/full-c-before.sha256" > "$out/full-c-after.stdout" 2> "$out/full-c-after.stderr"
printf '%s\n' "$?" > "$out/full-c-after.exit"
if [ "$build" -ne 0 ] || [ "$(cat "$out/full-c-after.exit")" -ne 0 ]; then exit 1; fi
sha256sum "$out/full-native" > "$out/native-binary.sha256"
step tests-native 20971520 "$out/full-native" +RTS --threads 1 --gpu off || exit 1
cmp "$out/tests-bend.stdout" "$out/tests-native.stdout" > "$out/tests-bend-native.diff" 2>&1
printf '%s\n' "$?" > "$out/tests-bend-native-cmp.exit"
date -u +%FT%TZ > "$out/native-finished.txt"
