/home/jadams/.local/share/writ-toolchains/bend-2.0.39/bend/bin/bend PROOF.bend 
