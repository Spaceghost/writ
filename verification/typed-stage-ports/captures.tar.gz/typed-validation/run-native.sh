#!/usr/bin/env bash
set -u
ulimit -c 0
export TMPDIR=/home/jadams/tmp/writ-codex-20261107 BEND_NO_TELEMETRY=1
unset BENDRTS
d=/home/jadams/tmp/writ-codex-20261107/typed-validation
preflight() {
 local name=$1 available
 available=$(awk '/^MemAvailable:/ {print $2}' /proc/meminfo)
 { date -u +%FT%TZ; printf 'MemAvailable %s KiB; required 41943040 KiB\n' "$available"; } > "$d/$name-memory.txt"
 [ -n "$available" ] && [ "$available" -ge 41943040 ] || { printf '%s\n' "$name preflight refused" > "$d/native-resource-stop.txt"; return 1; }
}
step() {
 local name=$1 limit=$2; shift 2
 preflight "$name" || return 42
 printf '%q ' "$@" > "$d/$name.command"; printf '\n' >> "$d/$name.command"
 date -u +%FT%TZ > "$d/$name.start"
 (ulimit -v "$limit"; ulimit -t 600; ulimit -f 262144; timeout 600 nice -n 15 "$@") > "$d/$name.stdout" 2> "$d/$name.stderr"
 local status=$?
 date -u +%FT%TZ > "$d/$name.end"; printf '%s\n' "$status" > "$d/$name.status"
 return "$status"
}
{ clang --version | head -1; sha256sum "$(readlink -f "$(command -v clang)")"; ld --version | head -1; printf '%s\n' 'build cap 16 GiB/run cap 20 GiB; wall and CPU 600 seconds; file 262144 blocks; no core'; } > "$d/native-environment.txt"
sha256sum "$d/Tests.c" > "$d/c-before.sha256"
step native-build 16777216 clang -std=c11 -O0 -static "$d/Tests.c" -o "$d/Tests-native" -lpthread -lm
status=$?
sha256sum -c "$d/c-before.sha256" > "$d/c-after.stdout" 2> "$d/c-after.stderr"; printf '%s\n' "$?" > "$d/c-after.status"
[ "$status" -eq 0 ] && [ "$(cat "$d/c-after.status")" -eq 0 ] || exit 1
sha256sum "$d/Tests-native" > "$d/native-binary.sha256"
step native-run 20971520 "$d/Tests-native" +RTS --threads 1 --gpu off || exit 1
cmp "$d/suite.stdout" "$d/native-run.stdout" > "$d/native-compare.stdout" 2> "$d/native-compare.stderr"; printf '%s\n' "$?" > "$d/native-compare.status"
