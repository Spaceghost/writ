nice -n 15 node /home/jadams/tmp/writ-codex-20261107/hostbinding-gap-evidence/witness.js 
