#!/usr/bin/env bash
set -u
cd /home/jadams/tmp/writ-hostbinding-close-gap-evidence || exit 1
export TMPDIR=/home/jadams/tmp/writ-codex-20261107 BEND_NO_TELEMETRY=1
b=/home/jadams/.local/share/writ-toolchains/bend-2.0.39/bend/bin/bend
d=/home/jadams/tmp/writ-codex-20261107/hostbinding-gap-evidence
run() { local name=$1; shift; printf '%q ' "$@" > "$d/$name.command"; printf '\n' >> "$d/$name.command"; "$@" > "$d/$name.stdout" 2> "$d/$name.stderr"; printf '%s\n' "$?" > "$d/$name.status"; }
run bend nice -n 15 "$b" verification/hostbinding-partial-close/witness.bend
run generate nice -n 15 "$b" verification/hostbinding-partial-close/witness.bend -o "$d/witness.js"
run node nice -n 15 node "$d/witness.js"
cmp "$d/bend.stdout" "$d/node.stdout" > "$d/compare.stdout" 2> "$d/compare.stderr"; printf '%s\n' "$?" > "$d/compare.status"
sha256sum "$b" "$d/witness.js" > "$d/tools-and-js.sha256"
node --version > "$d/node.version"
git rev-parse HEAD > "$d/source-revision.txt"
