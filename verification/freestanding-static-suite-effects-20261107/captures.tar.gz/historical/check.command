/bin/sh /home/jadams/tmp/writ-freestanding-checker-20261107/checker/check-binary.sh /home/jadams/tmp/writ-freestanding-hosted-20261107/historical/Tests
