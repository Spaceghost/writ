clang -std=c11 -O2 -static /home/jadams/tmp/writ-freestanding-freeze-20261107/outputs/current/Tests.c -o /home/jadams/tmp/writ-freestanding-hosted-20261107/retry-16g/Tests -lpthread -lm
