nice -n 15 /home/jadams/.local/share/writ-toolchains/bend-2.0.39/bend/bin/bend Tests.bend -o /home/jadams/tmp/writ-codex-20261107/typed-validation/Tests.js 
