clang -std=c11 -O0 -static /home/jadams/tmp/writ-linux-typed-session-validation/Tests.c -o /home/jadams/tmp/writ-linux-typed-session-validation/Tests-native -lpthread -lm 
