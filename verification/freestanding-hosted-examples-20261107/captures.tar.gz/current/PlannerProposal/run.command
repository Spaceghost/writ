/home/jadams/tmp/writ-freestanding-examples-20261107/current/PlannerProposal/PlannerProposal +RTS --threads 1 --gpu off
