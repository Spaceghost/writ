from pathlib import Path
import hashlib,re
base=Path('/home/jadams/tmp/writ-freestanding-examples-20261107')
blocks=re.findall(r'Captured output:\n\n```text\n(.*?)```', (base/'current-examples-readme.md').read_text(),re.S)
names=['Flow','Transfer','Commit','Parallel','StageGraph','PlannerProposal']
assert len(blocks)==len(names)
for name,block in zip(names,blocks):
 (base/'expected'/'current'/f'{name}.stdout').write_text(block)
assert hashlib.sha256(blocks[4].encode()).hexdigest()=='d3167692ac49a8051c177469d1a1947bcdb0fceb849da4ba6c9aab1dac57ad55'
assert hashlib.sha256(blocks[5].encode()).hexdigest()=='ba86437fc4749f6228d538dfdc8a270ca957c9f47ce2fccad6af49d7b83eb2bf'
