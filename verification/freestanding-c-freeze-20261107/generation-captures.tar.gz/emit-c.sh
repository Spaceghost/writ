#!/usr/bin/env bash
set -u
ulimit -c 0
export TMPDIR=/home/jadams/tmp/writ-codex-20261107
export BEND_NO_TELEMETRY=1
bend=/home/jadams/.local/share/writ-toolchains/bend-2.0.39/bend/bin/bend
base=/home/jadams/tmp/writ-freestanding-freeze-20261107
{
  printf 'UTC start: '; date -u +%FT%TZ
  printf 'Bend version: '; "$bend" version
  printf 'Bend executable: '; sha256sum "$bend"
  printf 'Bend release archive: '; sha256sum /home/jadams/.local/share/writ-toolchains/bend-2.0.39/release.tar.gz
  printf 'host: '; uname -a
} > "$base/environment.txt"
for tree in historical current; do
  cd "$base/$tree" || exit 1
  git rev-parse HEAD > "$base/outputs/$tree/source-commit.txt"
  git rev-parse 'HEAD^{tree}' > "$base/outputs/$tree/source-tree.txt"
  git status --short > "$base/outputs/$tree/source-status-before.txt"
  git ls-files -z -- '*.bend' | LC_ALL=C sort -z | xargs -0 sha256sum > "$base/outputs/$tree/source-bend-sha256.txt"
done
emit() {
  local tree=$1 input=$2 name=$3 dir="$base/outputs/$1"
  cd "$base/$tree" || return 1
  printf '%s\n' "timeout 600 $bend $input -o $dir/$name.c" > "$dir/$name.command.txt"
  date -u +%FT%TZ > "$dir/$name.start.txt"
  timeout 600 "$bend" "$input" -o "$dir/$name.c" > "$dir/$name.stdout" 2> "$dir/$name.stderr"
  local result=$?
  date -u +%FT%TZ > "$dir/$name.end.txt"
  printf '%s\n' "$result" > "$dir/$name.exit"
  if [ "$result" -eq 0 ] && [ -f "$dir/$name.c" ]; then (cd "$dir" && sha256sum "$name.c" > "$name.sha256"); fi
  printf '%s %s exit=%s\n' "$tree" "$input" "$result" >> "$base/progress.txt"
}
emit current scripts/runtime-profile/Hello.bend Hello
emit historical Tests.bend Tests
emit current Tests.bend Tests
for name in Flow Transfer Commit Parallel; do emit historical "examples/$name.bend" "$name"; done
for name in Flow Transfer Commit Parallel StageGraph PlannerProposal; do emit current "examples/$name.bend" "$name"; done
for tree in historical current; do
  cd "$base/$tree" || exit 1
  git status --short > "$base/outputs/$tree/source-status-after.txt"
done
date -u +%FT%TZ > "$base/finished.txt"
