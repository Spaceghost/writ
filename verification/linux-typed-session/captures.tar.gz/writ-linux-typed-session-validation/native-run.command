/home/jadams/tmp/writ-linux-typed-session-validation/Tests-native +RTS --threads 1 --gpu off 
