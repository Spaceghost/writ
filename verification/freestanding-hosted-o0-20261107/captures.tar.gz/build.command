clang -std=c11 -O0 -static /home/jadams/tmp/writ-freestanding-freeze-20261107/outputs/current/Tests.c -o /home/jadams/tmp/writ-freestanding-o0-20261107/Tests -lpthread -lm
