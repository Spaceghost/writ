/home/jadams/tmp/writ-freestanding-o0-20261107/Tests +RTS --threads 1 --gpu off
