﻿Executable: C:\Windows\System32\cmd.exe
Arguments: /d /c exit 0
Timeout seconds: 10
Working directory: C:\writ-stage
