TMPDIR=/home/jadams/tmp/writ-codex-20261107 BEND_NO_TELEMETRY=1 /home/jadams/.local/share/writ-toolchains/bend-2.0.39/bend/bin/bend hosts/linux/monitor/LinuxSessionOpenTests.bend
