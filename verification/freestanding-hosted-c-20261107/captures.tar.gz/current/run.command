/home/jadams/tmp/writ-freestanding-hosted-20261107/current/Tests +RTS --threads 1 --gpu off
