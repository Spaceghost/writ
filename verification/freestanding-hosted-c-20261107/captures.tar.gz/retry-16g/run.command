/home/jadams/tmp/writ-freestanding-hosted-20261107/retry-16g/Tests +RTS --threads 1 --gpu off
