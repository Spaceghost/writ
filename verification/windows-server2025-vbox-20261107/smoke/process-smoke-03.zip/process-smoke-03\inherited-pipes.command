﻿Executable: C:\writ-stage\public\portable-node\node.exe
Arguments: C:\writ-stage\pipe-parent.js
Timeout seconds: 10
Working directory: C:\writ-stage
