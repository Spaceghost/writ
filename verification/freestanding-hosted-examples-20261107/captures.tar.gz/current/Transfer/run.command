/home/jadams/tmp/writ-freestanding-examples-20261107/current/Transfer/Transfer +RTS --threads 1 --gpu off
