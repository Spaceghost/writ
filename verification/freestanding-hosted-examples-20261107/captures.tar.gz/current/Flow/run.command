/home/jadams/tmp/writ-freestanding-examples-20261107/current/Flow/Flow +RTS --threads 1 --gpu off
