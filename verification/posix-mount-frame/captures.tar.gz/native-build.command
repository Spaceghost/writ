clang -std=c11 -O0 -static /home/jadams/tmp/writ-posix-frame-verification/full.c -o /home/jadams/tmp/writ-posix-frame-verification/full-native -lpthread -lm 
