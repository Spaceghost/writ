node /home/jadams/tmp/writ-posix-frame-verification/full.js 
