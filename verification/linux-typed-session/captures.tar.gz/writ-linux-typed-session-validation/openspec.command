openspec validate --all --strict --no-interactive 
