#!/usr/bin/env bash
set -u
ulimit -c 0
export TMPDIR=/home/jadams/tmp/writ-codex-20261107
unset BENDRTS
base=/home/jadams/tmp/writ-freestanding-hosted-20261107
frozen=/home/jadams/tmp/writ-freestanding-freeze-20261107/outputs
{
  printf 'UTC start: '; date -u +%FT%TZ
  printf 'Compiler: '; clang --version | head -1
  printf 'Compiler path: '; command -v clang
  printf 'Compiler resolved: '; readlink -f "$(command -v clang)"
  sha256sum "$(readlink -f "$(command -v clang)")"
  printf 'Linker: '; ld --version | head -1
  printf 'glibc: '; ldd --version | head -1
  printf 'System: '; uname -a
  printf 'Build limits: nice 15; 600s wall; 600s CPU; 8388608 KiB virtual memory; 262144 blocks file size; core disabled\n'
  printf 'Run limits: nice 15; 600s wall; 600s CPU; 20971520 KiB virtual memory; 262144 blocks file size; core disabled\n'
} > "$base/environment.txt"
for tree in historical current; do
  dir="$base/$tree"
  cdir="$frozen/$tree"
  printf 'clang -std=c11 -O2 -static %s/Tests.c -o %s/Tests -lpthread -lm\n' "$cdir" "$dir" > "$dir/build.command"
  printf '%s/Tests +RTS --threads 1 --gpu off\n' "$dir" > "$dir/run.command"
  (cd "$cdir" && sha256sum -c Tests.sha256) > "$dir/hash-before.stdout" 2> "$dir/hash-before.stderr"
  result=$?
  printf '%s\n' "$result" > "$dir/hash-before.exit"
  if [ "$result" -ne 0 ]; then printf '%s input hash refused\n' "$tree" >> "$base/progress.txt"; continue; fi
  date -u +%FT%TZ > "$dir/build.start"
  (ulimit -v 8388608; ulimit -t 600; ulimit -f 262144; timeout 600 clang -std=c11 -O2 -static "$cdir/Tests.c" -o "$dir/Tests" -lpthread -lm) > "$dir/build.stdout" 2> "$dir/build.stderr"
  result=$?
  date -u +%FT%TZ > "$dir/build.end"
  printf '%s\n' "$result" > "$dir/build.exit"
  (cd "$cdir" && sha256sum -c Tests.sha256) > "$dir/hash-after.stdout" 2> "$dir/hash-after.stderr"
  hash_result=$?
  printf '%s\n' "$hash_result" > "$dir/hash-after.exit"
  if [ "$result" -ne 0 ] || [ "$hash_result" -ne 0 ]; then printf '%s build=%s hash-after=%s\n' "$tree" "$result" "$hash_result" >> "$base/progress.txt"; continue; fi
  sha256sum "$dir/Tests" > "$dir/binary.sha256"
  date -u +%FT%TZ > "$dir/run.start"
  (ulimit -v 20971520; ulimit -t 600; ulimit -f 262144; timeout 600 "$dir/Tests" +RTS --threads 1 --gpu off) > "$dir/run.stdout" 2> "$dir/run.stderr"
  result=$?
  date -u +%FT%TZ > "$dir/run.end"
  printf '%s\n' "$result" > "$dir/run.exit"
  printf '%s build=0 run=%s hash-after=%s\n' "$tree" "$result" "$hash_result" >> "$base/progress.txt"
done
date -u +%FT%TZ > "$base/finished.txt"
