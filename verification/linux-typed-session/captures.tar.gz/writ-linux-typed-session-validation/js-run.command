nice -n 15 node /home/jadams/tmp/writ-linux-typed-session-validation/Tests.js 
