﻿Executable: C:\Windows\System32\cmd.exe
Arguments: /d /c echo(OUTMARKER&1>&2 echo(ERRMARKER&exit 0
Timeout seconds: 10
Working directory: C:\writ-stage
