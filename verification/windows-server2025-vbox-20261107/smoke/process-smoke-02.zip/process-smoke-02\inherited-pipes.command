﻿Executable: C:\writ-stage\public\portable-node\node.exe
Arguments: -e "require('node:child_process').spawn(process.execPath,['-e','setTimeout(()=>{},12000)'],{stdio:'inherit'}).unref();process.exit(0)"
Timeout seconds: 10
Working directory: C:\writ-stage
