#!/usr/bin/env bash
set -u
ulimit -c 0
export TMPDIR=/home/jadams/tmp/writ-codex-20261107
export BEND_NO_TELEMETRY=1
unset BENDRTS
out=/home/jadams/tmp/writ-posix-frame-verification
bend=/home/jadams/.local/share/writ-toolchains/bend-2.0.39/bend/bin/bend
kernel=/tmp/writ-lean-434-isolated/kernel-audit/bendtt
{
 printf 'UTC '; date -u +%FT%TZ
 printf 'Bend '; "$bend" version
 sha256sum "$bend" "$kernel"
 printf 'Node '; node --version
 printf 'Host '; uname -a
 printf 'Each step: nice 15, 600-second wall/CPU cap, 20 GiB VM cap, bounded output, no core files\n'
} > "$out/environment.txt"
step() {
 local name=$1; shift
 printf '%q ' "$@" > "$out/$name.command"; printf '\n' >> "$out/$name.command"
 date -u +%FT%TZ > "$out/$name.start"
 (ulimit -v 20971520; ulimit -t 600; ulimit -f 262144; timeout 600 "$@") > "$out/$name.stdout" 2> "$out/$name.stderr"
 local result=$?
 date -u +%FT%TZ > "$out/$name.end"
 printf '%s\n' "$result" > "$out/$name.exit"
 printf '%s exit=%s\n' "$name" "$result" >> "$out/core-progress.txt"
 return "$result"
}
step tests-bend "$bend" Tests.bend || exit 1
step tests-js-build "$bend" Tests.bend -o "$out/full.js" || exit 1
step tests-node node "$out/full.js" || exit 1
cmp "$out/tests-bend.stdout" "$out/tests-node.stdout" > "$out/tests-bend-node.diff" 2>&1
printf '%s\n' "$?" > "$out/tests-bend-node-cmp.exit"
step proof "$bend" PROOF.bend || exit 1
step verdict env BENDTT="$kernel" "$bend" PROOF.bend --verdict || exit 1
step verdict-negative env BENDTT=/bin/false "$bend" PROOF.bend --verdict
negative=$?
printf 'negative=%s\n' "$negative" >> "$out/core-progress.txt"
if [ "$negative" -eq 0 ]; then exit 1; fi
sha256sum "$kernel" > "$out/kernel-after.sha256"
date -u +%FT%TZ > "$out/core-finished.txt"
