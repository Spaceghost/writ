#!/usr/bin/env bash
set -u
cd /home/jadams/tmp/writ-linux-typed-session-model || exit 1
export TMPDIR=/home/jadams/tmp/writ-codex-20261107 BEND_NO_TELEMETRY=1
unset BENDRTS
ulimit -c 0
d=/home/jadams/tmp/writ-linux-typed-session-validation
b=/home/jadams/.local/share/writ-toolchains/bend-2.0.39/bend/bin/bend
step() { local name=$1 limit=$2; shift 2; local available; available=$(awk '/^MemAvailable:/ {print $2}' /proc/meminfo); printf 'MemAvailable %s KiB; required 41943040 KiB\n' "$available" > "$d/$name-memory.txt"; if [ "$available" -lt 41943040 ]; then printf '42\n' > "$d/$name.status"; return 42; fi; printf '%q ' "$@" > "$d/$name.command"; printf '\n' >> "$d/$name.command"; date -u +%FT%TZ > "$d/$name.start"; (ulimit -v "$limit"; ulimit -t 600; ulimit -f 262144; timeout 600 nice -n 15 "$@") > "$d/$name.stdout" 2> "$d/$name.stderr"; local result=$?; date -u +%FT%TZ > "$d/$name.end"; printf '%s\n' "$result" > "$d/$name.status"; return "$result"; }
step c-generate 16777216 "$b" Tests.bend -o "$d/Tests.c" || exit 1
sha256sum "$d/Tests.c" > "$d/c-before.sha256"
step native-build 16777216 clang -std=c11 -O0 -static "$d/Tests.c" -o "$d/Tests-native" -lpthread -lm || exit 1
sha256sum -c "$d/c-before.sha256" > "$d/c-after.stdout" 2> "$d/c-after.stderr" || exit 1
step native-run 20971520 "$d/Tests-native" +RTS --threads 1 --gpu off || exit 1
