/home/jadams/tmp/writ-freestanding-examples-20261107/current/StageGraph/StageGraph +RTS --threads 1 --gpu off
