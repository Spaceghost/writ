/home/jadams/tmp/writ-codex-20261107/typed-validation/Tests-native +RTS --threads 1 --gpu off 
