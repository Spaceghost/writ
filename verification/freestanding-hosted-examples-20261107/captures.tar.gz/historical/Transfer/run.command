/home/jadams/tmp/writ-freestanding-examples-20261107/historical/Transfer/Transfer +RTS --threads 1 --gpu off
