clang -std=c11 -O2 -static /home/jadams/tmp/writ-freestanding-freeze-20261107/outputs/current/Flow.c -o /home/jadams/tmp/writ-freestanding-examples-20261107/current/Flow/Flow -lpthread -lm
