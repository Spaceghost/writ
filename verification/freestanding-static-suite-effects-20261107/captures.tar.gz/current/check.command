/bin/sh /home/jadams/tmp/writ-freestanding-checker-20261107/checker/check-binary.sh /home/jadams/tmp/writ-freestanding-o0-20261107/Tests
