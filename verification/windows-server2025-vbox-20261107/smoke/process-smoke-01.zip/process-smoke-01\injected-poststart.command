﻿Executable: C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe
Arguments: -NoProfile -NonInteractive -Command "Start-Sleep -Seconds 20"
Timeout seconds: 10
Working directory: C:\writ-stage
