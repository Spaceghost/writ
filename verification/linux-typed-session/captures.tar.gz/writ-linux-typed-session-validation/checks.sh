#!/usr/bin/env bash
set -u
cd /home/jadams/tmp/writ-linux-typed-session-model || exit 1
export TMPDIR=/home/jadams/tmp/writ-codex-20261107 BEND_NO_TELEMETRY=1
b=/home/jadams/.local/share/writ-toolchains/bend-2.0.39/bend/bin/bend
d=/home/jadams/tmp/writ-linux-typed-session-validation
run() { local name=$1; shift; printf '%q ' "$@" > "$d/$name.command"; printf '\n' >> "$d/$name.command"; "$@" > "$d/$name.stdout" 2> "$d/$name.stderr"; printf '%s\n' "$?" > "$d/$name.status"; }
run suite nice -n 15 "$b" Tests.bend
run js-generate nice -n 15 "$b" Tests.bend -o "$d/Tests.js"
run js-run nice -n 15 node "$d/Tests.js"
cmp "$d/suite.stdout" "$d/js-run.stdout" > "$d/js-compare.stdout" 2> "$d/js-compare.stderr"; printf '%s\n' "$?" > "$d/js-compare.status"
run proof nice -n 15 "$b" PROOF.bend
run verdict env BENDTT=/tmp/writ-lean-434-isolated/kernel-audit/bendtt nice -n 15 "$b" PROOF.bend --verdict
run verdict-negative env BENDTT=/bin/false nice -n 15 "$b" PROOF.bend --verdict
run openspec openspec validate --all --strict --no-interactive
