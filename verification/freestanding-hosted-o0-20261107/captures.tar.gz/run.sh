#!/usr/bin/env bash
set -u
ulimit -c 0
export TMPDIR=/home/jadams/tmp/writ-codex-20261107
unset BENDRTS
base=/home/jadams/tmp/writ-freestanding-o0-20261107
frozen=/home/jadams/tmp/writ-freestanding-freeze-20261107/outputs
repo=/mnt/MediaVolume/Media/src/github.com/spaceghost/writ
reference="$repo/verification/windev-model-bridge-20261107/full.stdout"
{
  printf 'UTC start: '; date -u +%FT%TZ
  printf 'Compiler: '; clang --version | head -1
  printf 'Compiler path: '; readlink -f "$(command -v clang)"
  sha256sum "$(readlink -f "$(command -v clang)")"
  printf 'Linker: '; ld --version | head -1
  printf 'glibc: '; ldd --version | head -1
  printf 'System: '; uname -a
  printf 'Build limits: nice 15; 600s wall; 600s CPU; 16777216 KiB virtual memory; 262144 blocks file size; core disabled\n'
  printf 'Run limits: nice 15; 600s wall; 600s CPU; 20971520 KiB virtual memory; 262144 blocks file size; core disabled\n'
} > "$base/environment.txt"
git -C "$repo" show 7d8b24c:verification/freestanding-c-freeze-20261107/generated-sha256.txt > "$base/committed-freeze-sha256.txt"
expected=$(awk '$2 == "current/Tests.c" { print $1 }' "$base/committed-freeze-sha256.txt")
printf '%s  %s\n' "$expected" "$frozen/current/Tests.c" > "$base/expected.sha256"
sha256sum -c "$base/expected.sha256" > "$base/hash-before.stdout" 2> "$base/hash-before.stderr"
hash_result=$?
printf '%s\n' "$hash_result" > "$base/hash-before.exit"
if [ "$hash_result" -ne 0 ]; then printf 'hash check failed\n' > "$base/skipped.txt"; exit 0; fi
printf 'clang -std=c11 -O0 -static %s/current/Tests.c -o %s/Tests -lpthread -lm\n' "$frozen" "$base" > "$base/build.command"
printf '%s/Tests +RTS --threads 1 --gpu off\n' "$base" > "$base/run.command"
available=$(awk '/^MemAvailable:/ { print $2 }' /proc/meminfo)
{ printf 'UTC '; date -u +%FT%TZ; printf 'MemAvailable %s KiB; minimum 41943040 KiB\n' "$available"; } > "$base/build-memavailable.txt"
if [ -z "$available" ] || [ "$available" -lt 41943040 ]; then printf 'insufficient available host memory before build\n' > "$base/skipped.txt"; exit 0; fi
date -u +%FT%TZ > "$base/build.start"
(ulimit -v 16777216; ulimit -t 600; ulimit -f 262144; timeout 600 clang -std=c11 -O0 -static "$frozen/current/Tests.c" -o "$base/Tests" -lpthread -lm) > "$base/build.stdout" 2> "$base/build.stderr"
result=$?
date -u +%FT%TZ > "$base/build.end"
printf '%s\n' "$result" > "$base/build.exit"
sha256sum -c "$base/expected.sha256" > "$base/hash-after.stdout" 2> "$base/hash-after.stderr"
hash_result=$?
printf '%s\n' "$hash_result" > "$base/hash-after.exit"
if [ "$result" -ne 0 ] || [ "$hash_result" -ne 0 ]; then exit 0; fi
sha256sum "$base/Tests" > "$base/binary.sha256"
available=$(awk '/^MemAvailable:/ { print $2 }' /proc/meminfo)
{ printf 'UTC '; date -u +%FT%TZ; printf 'MemAvailable %s KiB; minimum 41943040 KiB\n' "$available"; } > "$base/run-memavailable.txt"
if [ -z "$available" ] || [ "$available" -lt 41943040 ]; then printf 'insufficient available host memory before run\n' > "$base/run-skipped.txt"; exit 0; fi
date -u +%FT%TZ > "$base/run.start"
(ulimit -v 20971520; ulimit -t 600; ulimit -f 262144; timeout 600 "$base/Tests" +RTS --threads 1 --gpu off) > "$base/run.stdout" 2> "$base/run.stderr"
result=$?
date -u +%FT%TZ > "$base/run.end"
printf '%s\n' "$result" > "$base/run.exit"
if [ -f "$reference" ]; then
  sha256sum "$reference" > "$base/reference.sha256"
  cmp "$base/run.stdout" "$reference" > "$base/cmp-reference.stdout" 2> "$base/cmp-reference.stderr"
  printf '%s\n' "$?" > "$base/cmp-reference.exit"
fi
