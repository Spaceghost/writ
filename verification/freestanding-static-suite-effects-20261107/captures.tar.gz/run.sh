#!/usr/bin/env bash
set -u
ulimit -c 0
export TMPDIR=/home/jadams/tmp/writ-codex-20261107
base=/home/jadams/tmp/writ-freestanding-checker-20261107
{
  printf 'UTC start: '; date -u +%FT%TZ
  printf 'Checker source commit: '; git -C /mnt/MediaVolume/Media/src/github.com/spaceghost/writ rev-parse f786ece
  printf 'nm: '; nm --version | head -1
  printf 'readelf: '; readelf --version | head -1
  printf 'Host: '; uname -a
  printf 'Limits: nice 15; 300s wall; 300s CPU; 2097152 KiB virtual memory; 262144 blocks file size; core disabled\n'
} > "$base/environment.txt"
check_one() {
  local name=$1 binary=$2 expected=$3 dir="$base/$1"
  printf '%s  %s\n' "$expected" "$binary" > "$dir/input.sha256"
  sha256sum -c "$dir/input.sha256" > "$dir/hash-before.stdout" 2> "$dir/hash-before.stderr"
  local check=$?
  printf '%s\n' "$check" > "$dir/hash-before.exit"
  if [ "$check" -ne 0 ]; then printf '%s: hash mismatch\n' "$name" >> "$base/progress.txt"; return 0; fi
  printf '/bin/sh %s/checker/check-binary.sh %s\n' "$base" "$binary" > "$dir/check.command"
  local available
  available=$(awk '/^MemAvailable:/ {print $2}' /proc/meminfo)
  { printf 'UTC '; date -u +%FT%TZ; printf 'MemAvailable %s KiB; minimum 41943040 KiB\n' "$available"; } > "$dir/memavailable.txt"
  if [ -z "$available" ] || [ "$available" -lt 41943040 ]; then printf '%s: insufficient available host memory\n' "$name" > "$base/resource-stop.txt"; return 42; fi
  date -u +%FT%TZ > "$dir/check.start"
  (ulimit -v 2097152; ulimit -t 300; ulimit -f 262144; timeout 300 /bin/sh "$base/checker/check-binary.sh" "$binary") > "$dir/check.stdout" 2> "$dir/check.stderr"
  local result=$?
  date -u +%FT%TZ > "$dir/check.end"
  printf '%s\n' "$result" > "$dir/check.exit"
  sha256sum -c "$dir/input.sha256" > "$dir/hash-after.stdout" 2> "$dir/hash-after.stderr"
  local after=$?
  printf '%s\n' "$after" > "$dir/hash-after.exit"
  printf '%s checker=%s hash-after=%s\n' "$name" "$result" "$after" >> "$base/progress.txt"
}
check_one historical /home/jadams/tmp/writ-freestanding-hosted-20261107/historical/Tests 4fb1c6d9f594aa97097c4f1ef4835517c90ea6d8b07f5ff453fc83cee67fcf88 || exit 42
check_one current /home/jadams/tmp/writ-freestanding-o0-20261107/Tests 2b2653b2234aab3fe2778711f5365b29c8ae338f81fad54a65d0c3ef1c47d01f || exit 42
date -u +%FT%TZ > "$base/finished.txt"
