/home/jadams/tmp/writ-freestanding-examples-20261107/current/Commit/Commit +RTS --threads 1 --gpu off
