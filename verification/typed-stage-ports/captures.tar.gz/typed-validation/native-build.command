clang -std=c11 -O0 -static /home/jadams/tmp/writ-codex-20261107/typed-validation/Tests.c -o /home/jadams/tmp/writ-codex-20261107/typed-validation/Tests-native -lpthread -lm 
