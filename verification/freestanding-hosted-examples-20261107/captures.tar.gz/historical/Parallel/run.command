/home/jadams/tmp/writ-freestanding-examples-20261107/historical/Parallel/Parallel +RTS --threads 1 --gpu off
