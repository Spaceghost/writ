#!/usr/bin/env bash
set -u
ulimit -c 0
export TMPDIR=/home/jadams/tmp/writ-codex-20261107
unset BENDRTS
base=/home/jadams/tmp/writ-freestanding-examples-20261107
frozen=/home/jadams/tmp/writ-freestanding-freeze-20261107/outputs
{
  printf 'UTC start: '; date -u +%FT%TZ
  printf 'Compiler: '; clang --version | head -1
  printf 'Compiler path: '; readlink -f "$(command -v clang)"
  sha256sum "$(readlink -f "$(command -v clang)")"
  printf 'Linker: '; ld --version | head -1
  printf 'glibc: '; ldd --version | head -1
  printf 'System: '; uname -a
  printf 'Build limits: nice 15; 300s wall; 300s CPU; 8388608 KiB virtual memory; 262144 blocks file size; core disabled\n'
  printf 'Run limits: nice 15; 300s wall; 300s CPU; 20971520 KiB virtual memory; 262144 blocks file size; core disabled\n'
} > "$base/environment.txt"
preflight() {
  local outfile=$1 stage=$2 available
  available=$(awk '/^MemAvailable:/ {print $2}' /proc/meminfo)
  { printf 'UTC '; date -u +%FT%TZ; printf 'MemAvailable %s KiB; minimum 41943040 KiB\n' "$available"; } > "$outfile"
  if [ -z "$available" ] || [ "$available" -lt 41943040 ]; then
    printf '%s: insufficient host memory; batch stopped\n' "$stage" > "$base/resource-stop.txt"
    return 1
  fi
}
run_example() {
  local tree=$1 name=$2 dir="$base/$1/$2" source="$frozen/$1/$2.c" expected
  mkdir -p "$dir"
  expected=$(awk -v name="$tree/$name.c" '$2 == name {print $1}' "$base/committed-freeze-sha256.txt")
  printf '%s  %s\n' "$expected" "$source" > "$dir/input.sha256"
  sha256sum -c "$dir/input.sha256" > "$dir/hash-before.stdout" 2> "$dir/hash-before.stderr"
  local check=$?
  printf '%s\n' "$check" > "$dir/hash-before.exit"
  if [ "$check" -ne 0 ]; then printf '%s/%s input hash refused\n' "$tree" "$name" >> "$base/progress.txt"; return 0; fi
  printf 'clang -std=c11 -O2 -static %s -o %s/%s -lpthread -lm\n' "$source" "$dir" "$name" > "$dir/build.command"
  printf '%s/%s +RTS --threads 1 --gpu off\n' "$dir" "$name" > "$dir/run.command"
  preflight "$dir/build-memavailable.txt" "$tree/$name build" || return 42
  date -u +%FT%TZ > "$dir/build.start"
  (ulimit -v 8388608; ulimit -t 300; ulimit -f 262144; timeout 300 clang -std=c11 -O2 -static "$source" -o "$dir/$name" -lpthread -lm) > "$dir/build.stdout" 2> "$dir/build.stderr"
  local result=$?
  date -u +%FT%TZ > "$dir/build.end"
  printf '%s\n' "$result" > "$dir/build.exit"
  sha256sum -c "$dir/input.sha256" > "$dir/hash-after.stdout" 2> "$dir/hash-after.stderr"
  local hash_result=$?
  printf '%s\n' "$hash_result" > "$dir/hash-after.exit"
  if [ "$result" -ne 0 ] || [ "$hash_result" -ne 0 ]; then printf '%s/%s build=%s hash-after=%s\n' "$tree" "$name" "$result" "$hash_result" >> "$base/progress.txt"; return 0; fi
  sha256sum "$dir/$name" > "$dir/binary.sha256"
  preflight "$dir/run-memavailable.txt" "$tree/$name run" || return 42
  date -u +%FT%TZ > "$dir/run.start"
  (ulimit -v 20971520; ulimit -t 300; ulimit -f 262144; timeout 300 "$dir/$name" +RTS --threads 1 --gpu off) > "$dir/run.stdout" 2> "$dir/run.stderr"
  result=$?
  date -u +%FT%TZ > "$dir/run.end"
  printf '%s\n' "$result" > "$dir/run.exit"
  cmp "$dir/run.stdout" "$base/expected/$tree/$name.stdout" > "$dir/compare.stdout" 2> "$dir/compare.stderr"
  local cmp_result=$?
  printf '%s\n' "$cmp_result" > "$dir/compare.exit"
  printf '%s/%s build=0 run=%s compare=%s hash-after=%s\n' "$tree" "$name" "$result" "$cmp_result" "$hash_result" >> "$base/progress.txt"
}
for name in Flow Transfer Commit Parallel; do run_example historical "$name" || exit 42; done
for name in Flow Transfer Commit Parallel StageGraph PlannerProposal; do run_example current "$name" || exit 42; done
date -u +%FT%TZ > "$base/finished.txt"
