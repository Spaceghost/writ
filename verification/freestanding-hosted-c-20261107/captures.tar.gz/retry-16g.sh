#!/usr/bin/env bash
set -u
ulimit -c 0
export TMPDIR=/home/jadams/tmp/writ-codex-20261107
unset BENDRTS
base=/home/jadams/tmp/writ-freestanding-hosted-20261107
out="$base/retry-16g"
frozen=/home/jadams/tmp/writ-freestanding-freeze-20261107/outputs
inventory=/mnt/MediaVolume/Media/src/github.com/spaceghost/writ/verification/freestanding-c-freeze-20261107/generated-sha256.txt
expected=$(awk '$2 == "current/Tests.c" { print $1 }' "$inventory")
printf '%s  %s\n' "$expected" "$frozen/current/Tests.c" > "$out/expected.sha256"
sha256sum -c "$out/expected.sha256" > "$out/hash-before.stdout" 2> "$out/hash-before.stderr"
hash_result=$?
printf '%s\n' "$hash_result" > "$out/hash-before.exit"
if [ "$hash_result" -ne 0 ]; then printf 'hash check failed\n' > "$out/skipped.txt"; exit 0; fi
available=$(awk '/^MemAvailable:/ { print $2 }' /proc/meminfo)
printf 'UTC '; date -u +%FT%TZ
printf 'MemAvailable %s KiB; minimum 41943040 KiB\n' "$available"
if [ -z "$available" ] || [ "$available" -lt 41943040 ]; then printf 'insufficient available host memory\n' > "$out/skipped.txt"; exit 0; fi
printf 'clang -std=c11 -O2 -static %s/current/Tests.c -o %s/Tests -lpthread -lm\n' "$frozen" "$out" > "$out/build.command"
printf '%s/Tests +RTS --threads 1 --gpu off\n' "$out" > "$out/run.command"
date -u +%FT%TZ > "$out/build.start"
(ulimit -v 16777216; ulimit -t 600; ulimit -f 262144; timeout 600 clang -std=c11 -O2 -static "$frozen/current/Tests.c" -o "$out/Tests" -lpthread -lm) > "$out/build.stdout" 2> "$out/build.stderr"
result=$?
date -u +%FT%TZ > "$out/build.end"
printf '%s\n' "$result" > "$out/build.exit"
sha256sum -c "$out/expected.sha256" > "$out/hash-after.stdout" 2> "$out/hash-after.stderr"
hash_result=$?
printf '%s\n' "$hash_result" > "$out/hash-after.exit"
if [ "$result" -ne 0 ] || [ "$hash_result" -ne 0 ]; then exit 0; fi
sha256sum "$out/Tests" > "$out/binary.sha256"
date -u +%FT%TZ > "$out/run.start"
(ulimit -v 20971520; ulimit -t 600; ulimit -f 262144; timeout 600 "$out/Tests" +RTS --threads 1 --gpu off) > "$out/run.stdout" 2> "$out/run.stderr"
result=$?
date -u +%FT%TZ > "$out/run.end"
printf '%s\n' "$result" > "$out/run.exit"
