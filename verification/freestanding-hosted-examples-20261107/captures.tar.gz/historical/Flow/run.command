/home/jadams/tmp/writ-freestanding-examples-20261107/historical/Flow/Flow +RTS --threads 1 --gpu off
