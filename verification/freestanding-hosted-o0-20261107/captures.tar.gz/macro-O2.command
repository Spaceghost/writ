clang -E -P -O2 -x c /home/jadams/tmp/writ-freestanding-o0-20261107/macro-check.c
